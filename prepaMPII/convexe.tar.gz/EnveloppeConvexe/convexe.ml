open Graphics

type point = int * int

let draw_point (x,y : point) : unit =
  (* dessine un point aux coordonnees x, y *)
  set_color blue;
  fill_circle x y 3;
  set_color black

let get_coord (() : unit) : point =
  (* Attends un clique et renvoie les coordonnees du point *)
  let st = wait_next_event [Button_down] in
  st.mouse_x, st.mouse_y

let rec add_point (p : point) (l : point list) : point list =
  assert false

let dessine (l : point list) : unit =
  assert false

let main () =
  open_graph "";
  let points : point list ref = ref [] in
  while true do
    assert false
  done

let () = main ()
